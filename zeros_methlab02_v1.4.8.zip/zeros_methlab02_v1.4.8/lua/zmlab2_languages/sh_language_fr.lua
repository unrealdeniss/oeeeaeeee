--[[
Server Name: AetherNetwork.gg *HIRING* Craft|Bitcoin|Gangs|Meth|Weed|FastDL
Server IP:   193.243.190.5:27034
File Path:   addons/zeros_methlab02_v1.4.8/lua/zmlab2_languages/sh_language_fr.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

/*
    Addon id: a36a6eee-6041-4541-9849-360baff995a2
    Version: v1.4.8 (stable)
*/

zmlab2 = zmlab2 or {}
zmlab2.language = zmlab2.language or {}

if (zmlab2.config.SelectedLanguage == "fr") then
    zmlab2.language["YouDontOwnThis"] = "Vous ne possédez pas ceci!"
    zmlab2.language["Minutes"] = "Minutes"
    zmlab2.language["Seconds"] = "Secondes"
    zmlab2.language["CratePickupFail"] = "La caisse est vide!"
    zmlab2.language["CratePickupSuccess"] = "Collecté $MethAmount $MethName, Qualité: $MethQuality%"
    zmlab2.language["Interaction_Fail_Job"] = "Vous n'avez pas le bon travail pour interagir avec ceci!"
    zmlab2.language["Interaction_Fail_Dropoff"] = "Ce point de dépôt ne vous est pas attribué!"
    zmlab2.language["Dropoff_assinged"] = "Dépôt assigné!"
    zmlab2.language["Dropoff_cooldown"] = "Délai de pause!"
    zmlab2.language["Equipment"] = "Equipment"
    zmlab2.language["Equipment_Build"] = "Construire"
    zmlab2.language["Equipment_Move"] = "Bouger"
    zmlab2.language["Equipment_Repair"] = "Réparer"
    zmlab2.language["Equipment_Remove"] = "Retirer"
    zmlab2.language["NotEnoughMoney"] = "Vous n'avez pas assez d'argent!"
    zmlab2.language["ExtinguisherFail"] = "L'objet n'est pas en feu!"
    zmlab2.language["Start"] = "Commencer"
    zmlab2.language["Drop"] = "Lacher"
    zmlab2.language["Move Liquid"] = "Déplacer le liquide"
    zmlab2.language["Frezzer_NeedTray"] = "Aucun plateau avec de la méthamphétamine non congelée trouvé!"
    zmlab2.language["ERROR"] = "ERREUR"
    zmlab2.language["SPACE"] = "Appyez sur ESPACE"
    zmlab2.language["NPC_InteractionFail01"] = "Dégage de là! [Mauvais métier]"
    zmlab2.language["NPC_InteractionFail02"] = "Vous n'avez pas de meth!"
    zmlab2.language["NPC_InteractionFail03"] = "Je n'ai pas de point de dépôt libre actuellement, revenez plus tard."
    zmlab2.language["PoliceWanted"] = "Meth vendue!"
    zmlab2.language["MissingCrate"] = "Caisse manquante"
    zmlab2.language["Storage"] = "STOCKAGE"
    zmlab2.language["ItemLimit"] = "Vous avez atteint la limite d'entité pour $ItemName!"
    zmlab2.language["TentFoldInfo01"] = "Voulez-vous vraiment retirer la tente?"
    zmlab2.language["TentFoldInfo02"] = "Tout équipement à l'intérieur sera également supprimé!"
    zmlab2.language["TentFoldAction"] = "PLIER"
    zmlab2.language["TentType_None"] = "RIEN"
    zmlab2.language["TentAction_Build"] = "CONSTRUIRE"
    zmlab2.language["TentBuild_Info"] = "Veuillez dégager la zone!"
    zmlab2.language["TentBuild_Abort"] = "Quelque chose gêne!"
    zmlab2.language["Enabled"] = "Activé"
    zmlab2.language["Disabled"] = "Désactivé"
    zmlab2.language["MethTypeRestricted"] = "Vous n'êtes pas autorisé à fabriquer ce type de meth!"
    zmlab2.language["SelectMethType"] = "Sélectionnez le type de meth"
    zmlab2.language["SelectTentType"] = "Sélectionnez le type de tente"
    zmlab2.language["LightColor"] = "Couleur lampe"
    zmlab2.language["Cancel"] = "Annuler"
    zmlab2.language["Deconstruct"] = "Déconstruire"
    zmlab2.language["Construct"] = "Construire"
    zmlab2.language["Choosepostion"] = "Choisissez une nouvelle position"
    zmlab2.language["ChooseMachine"] = "Choisissez une nouvelle machine"
    zmlab2.language["Extinguish"] = "Éteindre"
    zmlab2.language["PumpTo"] = "Pomper à"
    zmlab2.language["ConstructionCompleted"] = "Construction completée!"
    zmlab2.language["Duration"] = "Durée"
    zmlab2.language["Amount"] = "Rendement"
    zmlab2.language["Difficulty"] = "Difficulté"
    zmlab2.language["Money"] = "Argent"
    zmlab2.language["Difficulty_Easy"] = "Facile"
    zmlab2.language["Difficulty_Medium"] = "Moyen"
    zmlab2.language["Difficulty_Hard"] = "Difficile"
    zmlab2.language["Difficulty_Expert"] = "Expert"
    zmlab2.language["Connected"] = "Attaché!"
    zmlab2.language["Missed"] = "Manqué!"

    // Tent shop
    // Note: "Vamonos Pest" and "Crystale Castle" are the names of those tents so you dont need to translate them if you dont want
    zmlab2.language["tent01_title"] = "Tente Vamonos Pest - Petite"
    zmlab2.language["tent01_desc"] = "Cette petite tente peut accueillir 6 machines."
    zmlab2.language["tent02_title"] = "Tente Vamonos Pest - Moyenne"
    zmlab2.language["tent02_desc"] = "Cette tente de taille moyenne peut accueillir 9 machines."
    zmlab2.language["tent03_title"] = "Tente Vamonos Pest - Grande"
    zmlab2.language["tent03_desc"] = "Cette grande tente peut accueillir 16 machines."
    zmlab2.language["tent04_title"] = "Crystale Castle"
    zmlab2.language["tent04_desc"] = "Cette tente de cirque volée offre de la place pour 24 machines."

    // Machine Shop
    zmlab2.language["ventilation_title"] = "Ventilation"
    zmlab2.language["ventilation_desc"] = "Nettoie la zone environnante de la pollution."
    zmlab2.language["storage_title"] = "Stockage"
    zmlab2.language["storage_desc"] = "Fournit des produits chimiques et de l'équipement."
    zmlab2.language["furnace_title"] = "Four au thorium"
    zmlab2.language["furnace_desc"] = "Utilisé pour chauffer l'acide."
    zmlab2.language["mixer_title"] = "Mixer"
    zmlab2.language["mixer_desc"] = "Utilisé comme récipient de réaction principal pour combiner les composés."
    zmlab2.language["filter_title"] = "Filtre"
    zmlab2.language["filter_desc"] = "Utilisé pour affiner le mélange final pour augmenter sa qualité."
    zmlab2.language["filler_title"] = "Remplisseur"
    zmlab2.language["filler_desc"] = "Utilisé pour remplir le mélange final sur des plateaux de congélation."
    zmlab2.language["frezzer_title"] = "Congélateur"
    zmlab2.language["frezzer_desc"] = "Utilisé pour empêcher la solution finale de méthamphétamine de réagir davantage."
    zmlab2.language["packingtable_title"] = "Table d'emballage"
    zmlab2.language["packingtable_desc"] = "Fournit un moyen rapide de casser/emballer la méthamphétamine. Peut contenir jusqu'à 12 plateaux de congélation. Peut être amélioré avec un brise-glace automatique."

    // Item Shop
    zmlab2.language["acid_title"] = "Acide hydrofluorique"
    zmlab2.language["acid_desc"] = "Un catalyseur pour augmenter la vitesse de réaction."
    zmlab2.language["methylamine_title"] = "Méthylamine"
    zmlab2.language["methylamine_desc"] = "Méthylamine (CH3NH2) est un composé organique et l'un des principaux ingrédients pour la production de méthamphétamine."
    zmlab2.language["aluminum_title"] = "Aluminium"
    zmlab2.language["aluminum_desc"] = "L'aluminium est utilisé comme réactif chimique pour réduire les composés."
    zmlab2.language["lox_title"] = "Oxygène liquide"
    zmlab2.language["lox_desc"] = "L'oxygène liquide est utilisé dans le congélateur pour empêcher la solution finale de méthamphétamine de réagir davantage."
    zmlab2.language["crate_title"] = "Caisse de transport"
    zmlab2.language["crate_desc"] = "Utilisé pour transporter de grandes quantités de méthamphétamine."
    zmlab2.language["palette_title"] = "Palette"
    zmlab2.language["palette_desc"] = "Utilisé pour transporter de grandes quantités de méthamphétamine."
    zmlab2.language["crusher_title"] = "Brise-glace"
    zmlab2.language["crusher_desc"] = "Casse et emballe automatiquement la méthamphétamine lorsqu'elle est installée sur une table d'emballage."

    // Meth Config
    // Note: Hard to say what about the meth should be translated and what not. Decide for yourself whats important here.
    zmlab2.language["meth_title"] = "Meth"
    zmlab2.language["meth_desc"] = "Meth de rue normale."
    zmlab2.language["bluemeth_title"] = "Crystal Blue"
    zmlab2.language["bluemeth_desc"] = "La formule originale de Heisenberg."
    zmlab2.language["kalaxi_title"] = "Kalaxian Crystal"
    zmlab2.language["kalaxi_desc"] = "Les cristaux de Kalaxian sont très similaires à de nombreux médicaments, car les cristaux vous donnent une bonne sensation."
    zmlab2.language["glitter_title"] = "Glitter"
    zmlab2.language["glitter_desc"] = "Glitter est une drogue hautement psychédélique et récemment arrivée dans les rues. C'est vraiment fort."
    zmlab2.language["kronole_title"] = "Kronole"
    zmlab2.language["kronole_desc"] = "Le Kronole est une drogue de rue vendue à bord de Snowpiercer sur le marché noir. Le médicament a la capacité de bloquer les récepteurs de la douleur, Kronole est si puissant qu'il bloque tous les sentiments, pas seulement la douleur."
    zmlab2.language["melange_title"] = "Melange"
    zmlab2.language["melange_desc"] = "Melange (Spice) est un médicament capable de prolonger la vie, de conférer une vitalité et une conscience accrues et de débloquer la prescience chez certains humains."
    zmlab2.language["mdma_title"] = "MDMA"
    zmlab2.language["mdma_desc"] = "MDMA a été développé pour la première fois en 1912 par Merck. Il a été utilisé pour améliorer la psychothérapie à partir des années 1970 et est devenu populaire en tant que drogue de rue dans les années 1980."

    // Update 1.0.5
    zmlab2.language["tent05_title"] = "Tente ronde"
    zmlab2.language["tent05_desc"] = "Cette tente offre de la place pour 8 machines."

    // Update 1.3.2
    zmlab2.language["Won"] = "Gagné"
    zmlab2.language["Lost"] = "Perdu"
    zmlab2.language["Remember"] = "Rappelle!"
    zmlab2.language["Repeat"] = "Répète!"
end
