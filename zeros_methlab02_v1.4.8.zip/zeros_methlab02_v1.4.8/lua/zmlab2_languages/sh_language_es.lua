--[[
Server Name: AetherNetwork.gg *HIRING* Craft|Bitcoin|Gangs|Meth|Weed|FastDL
Server IP:   193.243.190.5:27034
File Path:   addons/zeros_methlab02_v1.4.8/lua/zmlab2_languages/sh_language_es.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

/*
    Addon id: a36a6eee-6041-4541-9849-360baff995a2
    Version: v1.4.8 (stable)
*/

zmlab2 = zmlab2 or {}
zmlab2.language = zmlab2.language or {}

if (zmlab2.config.SelectedLanguage == "es") then
    zmlab2.language["YouDontOwnThis"] = "¡Esto no te pertenece!"
    zmlab2.language["Minutes"] = "Minutos"
    zmlab2.language["Seconds"] = "Segundos"
    zmlab2.language["CratePickupFail"] = "¡El contenedor está vacío!"
    zmlab2.language["CratePickupSuccess"] = "Has recogido $MethAmount $MethName, Calidad: $MethQuality%"
    zmlab2.language["Interaction_Fail_Job"] = "¡No tienes el trabajo adecuado para hacer eso!"
    zmlab2.language["Interaction_Fail_Dropoff"] = "¡Este punto de entrega no te fue asignado!"
    zmlab2.language["Dropoff_assinged"] = "¡Entrega coordinada!"
    zmlab2.language["Dropoff_cooldown"] = "¡Entrega en enfriamiento!"
    zmlab2.language["Equipment"] = "Equipamiento"
    zmlab2.language["Equipment_Build"] = "Construir"
    zmlab2.language["Equipment_Move"] = "Mover"
    zmlab2.language["Equipment_Repair"] = "Reparar"
    zmlab2.language["Equipment_Remove"] = "Remover"
    zmlab2.language["NotEnoughMoney"] = "¡No tienes dinero suficiente!"
    zmlab2.language["ExtinguisherFail"] = "¡El objeto no está en llamas!"
    zmlab2.language["Start"] = "Iniciar"
    zmlab2.language["Drop"] = "Soltar"
    zmlab2.language["Move Liquid"] = "Mover Líquido"
    zmlab2.language["Frezzer_NeedTray"] = "¡Bandeja con metanfetamina líquida no encontrada!"
    zmlab2.language["ERROR"] = "ERROR"
    zmlab2.language["SPACE"] = "Presiona ESPACIO"
    zmlab2.language["NPC_InteractionFail01"] = "¡No hago negocios con desconocidos! [Trabajo incorrecto]"
    zmlab2.language["NPC_InteractionFail02"] = "¡No tienes metanfetamina!"
    zmlab2.language["NPC_InteractionFail03"] = "No tengo un punto de entrega libre, vuelve más tarde."
    zmlab2.language["PoliceWanted"] = "¡Metanfetamina vendida!"
    zmlab2.language["MissingCrate"] = "No tienes contenedores"
    zmlab2.language["Storage"] = "ALMACENAMIENTO"
    zmlab2.language["ItemLimit"] = "¡Has alcanzado el límite de entidad para la entidad $ItemName!"
    zmlab2.language["TentFoldInfo01"] = "¿Estás seguro de que quieres remover la carpa?"
    zmlab2.language["TentFoldInfo02"] = "¡Todo lo que esté dentro será removido también!"
    zmlab2.language["TentFoldAction"] = "DOBLAR"
    zmlab2.language["TentType_None"] = "NADA"
    zmlab2.language["TentAction_Build"] = "Construir"
    zmlab2.language["TentBuild_Info"] = "¡Por favor, libera el área!"
    zmlab2.language["TentBuild_Abort"] = "¡Hay algo en el camino!"
    zmlab2.language["Enabled"] = "Habilitado"
    zmlab2.language["Disabled"] = "Deshabilitado"
    zmlab2.language["MethTypeRestricted"] = "¡No tienes permitido hacer este tipo de metanfetamina!"
    zmlab2.language["SelectMethType"] = "Selecciona el tipo de meta"
    zmlab2.language["SelectTentType"] = "Selecciona el tipo de carpa"
    zmlab2.language["LightColor"] = "Color de la luz"
    zmlab2.language["Cancel"] = "Cancelar"
    zmlab2.language["Deconstruct"] = "Desmontar"
    zmlab2.language["Construct"] = "Construir"
    zmlab2.language["Choosepostion"] = "Elige una nueva posición"
    zmlab2.language["ChooseMachine"] = "Elige una máquina"
    zmlab2.language["Extinguish"] = "Extinguir"
    zmlab2.language["PumpTo"] = "Bombear"
    zmlab2.language["ConstructionCompleted"] = "¡Construcción Completa!"
    zmlab2.language["Duration"] = "Duración"
    zmlab2.language["Amount"] = "Producir"
    zmlab2.language["Difficulty"] = "Dificultad"
    zmlab2.language["Money"] = "Dinero"
    zmlab2.language["Difficulty_Easy"] = "Fácil"
    zmlab2.language["Difficulty_Medium"] = "Media"
    zmlab2.language["Difficulty_Hard"] = "Difícil"
    zmlab2.language["Difficulty_Expert"] = "Experto"
    zmlab2.language["Connected"] = "¡Conectado!"
    zmlab2.language["Missed"] = "¡Fallado!"

    // Tent Config
    // Note: "Vamonos Pest" and "Crystale Castle" are the names of those tents so you dont need to translate them if you dont want
    zmlab2.language["tent01_title"] = "Carpa Vamonos Pest - Pequeña"
    zmlab2.language["tent01_desc"] = "Esta carpa pequeña admite hasta 6 máquinas."
    zmlab2.language["tent02_title"] = "Carpa Vamonos Pest - Media"
    zmlab2.language["tent02_desc"] = "Esta carpa mediana admite hasta 9 máquinas."
    zmlab2.language["tent03_title"] = "Carpa Vamonos Pest - Grande"
    zmlab2.language["tent03_desc"] = "Esta carpa grande admite hasta 16 máquinas."
    zmlab2.language["tent04_title"] = "Castillo de Cristal"
    zmlab2.language["tent04_desc"] = "Esta carpa de circo robada admite hasta 24 máquinas."

    // Equipment Config
    zmlab2.language["ventilation_title"] = "Ventilación"
    zmlab2.language["ventilation_desc"] = "Libera la zona circundante de contaminación."
    zmlab2.language["storage_title"] = "Almacenamiento"
    zmlab2.language["storage_desc"] = "Provee químicos y equipamiento."
    zmlab2.language["furnace_title"] = "Horno Torio"
    zmlab2.language["furnace_desc"] = "Usado para calentar ácido."
    zmlab2.language["mixer_title"] = "Mezclador"
    zmlab2.language["mixer_desc"] = "Utilizado como el dispositivo principal para mezclar productos."
    zmlab2.language["filter_title"] = "Filtro"
    zmlab2.language["filter_desc"] = "Utilizado para refinar la mezcla final para mejorar su calidad."
    zmlab2.language["filler_title"] = "Distribuidor"
    zmlab2.language["filler_desc"] = "Utilizado para rellenar las bandejas con la mezcla producida."
    zmlab2.language["frezzer_title"] = "Congelador"
    zmlab2.language["frezzer_desc"] = "Utilizado para evitar que la solución de metanfetamina continúe reaccionando."
    zmlab2.language["packingtable_title"] = "Mesa de Almacenamiento"
    zmlab2.language["packingtable_desc"] = "Provee una forma sencilla para picar / guardar la meta. Admite hasta 12 bandejas para congelador. Puede ser mejorada con un Picador de Cristales automático."

    // Storage Config
    zmlab2.language["acid_title"] = "Acido fluorhídrico"
    zmlab2.language["acid_desc"] = "Un catalizador para aumentar el porcentaje de reacción."
    zmlab2.language["methylamine_title"] = "Metilamina"
    zmlab2.language["methylamine_desc"] = "La Metilamina (CH3NH2) es un componente orgánico y uno de los ingredientes principales para la producción de meta."
    zmlab2.language["aluminum_title"] = "Aluminio"
    zmlab2.language["aluminum_desc"] = "El Aluminio amalgamado es utilizado como un componente agente para reducir reagent para reducir compuestos."
    zmlab2.language["lox_title"] = "Oxígeno Líquido"
    zmlab2.language["lox_desc"] = "El oxígeno Líquido es utilizado en el congelador para evitar que la solución de metanfetamina continúe reaccionando."
    zmlab2.language["crate_title"] = "Contenedor para transportar"
    zmlab2.language["crate_desc"] = "Utilizado para transportar grandes cantidades de meta."
    zmlab2.language["palette_title"] = "Paleta"
    zmlab2.language["palette_desc"] = "Utilizado para transportar varios contenedores con meta."
    zmlab2.language["crusher_title"] = "Picador de Cristales"
    zmlab2.language["crusher_desc"] = "Pica y almacena la meta automáticamente al ser instalada en una Mesa de Almacenamiento."

    // Meth Config
    // Note: Hard to say what about the meth should be translated and what not. Decide for yourself whats important here.
    zmlab2.language["meth_title"] = "Metanfetamina"
    zmlab2.language["meth_desc"] = "Metanfetamina común y corriente."
    zmlab2.language["bluemeth_title"] = "Metanfetamina Azul"
    zmlab2.language["bluemeth_desc"] = "La fórmula original del gran Heisenberg."
    zmlab2.language["kalaxi_title"] = "Cristales Kalaxian"
    zmlab2.language["kalaxi_desc"] = "La meta Kalaxiana es similar a otras drogas, ya que los cristales te dan una gran sensación."
    zmlab2.language["glitter_title"] = "Glitter"
    zmlab2.language["glitter_desc"] = "El Glitter es una droga psicodélica drug recién nacida de las calles de Night City. Es bastante fuerte, incluso para los veteranos de Night City."
    zmlab2.language["kronole_title"] = "Kronole"
    zmlab2.language["kronole_desc"] = "El Kronole es una droga callejera vendida por Snowpiercer en el mercado negro. Esta droga permite no sentir dolor, además de muchos otros sentidos."
    zmlab2.language["melange_title"] = "Mezclado"
    zmlab2.language["melange_desc"] = "El Mezclado (Especia) es una droga que permite alargar el tiempo de vida, otorgando mayor vitalidad y conciencia, además de permitirle predecir el futuro a algunas personas."
    zmlab2.language["mdma_title"] = "MDMA"
    zmlab2.language["mdma_desc"] = "La MDMA fue creada en 1912 por Merck. Fue utilizada para mejorar la terapia psicológica al principio de 1970 y se volvió popular como droga callejera a partir del 1980."

    // Update 1.0.5
    zmlab2.language["tent05_title"] = "Carpa Redonda"
    zmlab2.language["tent05_desc"] = "Esta carpa redonda admite hasta 8 máquinas."

	-- Update 1.3.2
    zmlab2.language["Won"] = "Won"
	zmlab2.language["Lost"] = "Lost"
    zmlab2.language["Remember"] = "Remember!"
	zmlab2.language["Repeat"] = "Repeat!"
end
