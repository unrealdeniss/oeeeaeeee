--[[
Server Name: AetherNetwork.gg *HIRING* Craft|Bitcoin|Gangs|Meth|Weed|FastDL
Server IP:   193.243.190.5:27034
File Path:   addons/zeros_methlab02_v1.4.8/lua/zmlab2_languages/sh_language_de.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

/*
    Addon id: a36a6eee-6041-4541-9849-360baff995a2
    Version: v1.4.8 (stable)
*/

zmlab2 = zmlab2 or {}
zmlab2.language = zmlab2.language or {}

if (zmlab2.config.SelectedLanguage == "de") then
    zmlab2.language["YouDontOwnThis"] = "Das gehört dir nicht!"
    zmlab2.language["Minutes"] = "Minuten"
    zmlab2.language["Seconds"] = "Sekunden"
    zmlab2.language["CratePickupFail"] = "Die Transportkiste ist leer!"
    zmlab2.language["CratePickupSuccess"] = "Du hast $MethAmount $MethName, mit der Qualität: $MethQuality% aufgesammelt!"
    zmlab2.language["Interaction_Fail_Job"] = "Du hast nicht den richtigen Job, um damit zu interagieren!"
    zmlab2.language["Interaction_Fail_Dropoff"] = "Dieser Abwurfspunkt ist dir nicht zugewiesen!"
    zmlab2.language["Dropoff_assinged"] = "Abwurfspunkt zugewiesen!"
    zmlab2.language["Dropoff_cooldown"] = "Abwurfspunkt cooldown!"
    zmlab2.language["Equipment"] = "Ausrüstung"
    zmlab2.language["Equipment_Build"] = "Bauen"
    zmlab2.language["Equipment_Move"] = "Bewegen"
    zmlab2.language["Equipment_Repair"] = "Reparieren"
    zmlab2.language["Equipment_Remove"] = "Löschen"
    zmlab2.language["NotEnoughMoney"] = "Du hast nicht genug Geld!"
    zmlab2.language["ExtinguisherFail"] = "Objekt brennt nicht!"
    zmlab2.language["Start"] = "Starten"
    zmlab2.language["Drop"] = "Entnehmen"
    zmlab2.language["Move Liquid"] = "Umfüllen"
    zmlab2.language["Frezzer_NeedTray"] = "Der Gefrierschrank benötigt ein Tablett!"
    zmlab2.language["ERROR"] = "ERROR"
    zmlab2.language["SPACE"] = "Drücke LEERTASTE"
    zmlab2.language["NPC_InteractionFail01"] = "Mit dir rede ich nicht! [Falscher Job]"
    zmlab2.language["NPC_InteractionFail02"] = "Du hast kein Meth bei dir!"
    zmlab2.language["NPC_InteractionFail03"] = "Ich habe momentan keinen freien Abwurfspunkt, komm später wieder!"
    zmlab2.language["PoliceWanted"] = "Meth verkauft!"
    zmlab2.language["MissingCrate"] = "Kiste fehlt!"
    zmlab2.language["Storage"] = "LAGER"
    zmlab2.language["ItemLimit"] = "Du hast das Limit von dem Item  '$ItemName' erreicht!"
    zmlab2.language["TentFoldInfo01"] = "Bist du sicher, dass du das Zelt abbauen willst?"
    zmlab2.language["TentFoldInfo02"] = "Jede Maschine die sich im Zelt befindet, wird dann verkauft!"
    zmlab2.language["TentFoldAction"] = "Abbauen"
    zmlab2.language["TentType_None"] = "Kein Zelt"
    zmlab2.language["TentAction_Build"] = "Bauen"
    zmlab2.language["TentBuild_Info"] = "Bitte mache den Bereich frei!"
    zmlab2.language["TentBuild_Abort"] = "Etwas war im weg!"
    zmlab2.language["Enabled"] = "Eingeschalten"
    zmlab2.language["Disabled"] = "Ausgeschalten"
    zmlab2.language["MethTypeRestricted"] = "Du darfst diesen Typ von Meth nicht herstellen!"
    zmlab2.language["SelectMethType"] = "Wähle den Methtyp"
    zmlab2.language["SelectTentType"] = "Wähle ein Zelt"
    zmlab2.language["LightColor"] = "Lichtfarbe"
    zmlab2.language["Cancel"] = "Abbrechen"
    zmlab2.language["Deconstruct"] = "Abbauen"
    zmlab2.language["Construct"] = "Bauen"
    zmlab2.language["Choosepostion"] = "Platzieren"
    zmlab2.language["ChooseMachine"] = "Wähle eine Maschine"
    zmlab2.language["Extinguish"] = "Feuer löschen"
    zmlab2.language["PumpTo"] = "Umfüllen"
    zmlab2.language["ConstructionCompleted"] = "Bau abgeschlossen!"
    zmlab2.language["Duration"] = "Dauer"
    zmlab2.language["Amount"] = "Menge"
    zmlab2.language["Difficulty"] = "Schwierigkeit"
    zmlab2.language["Money"] = "Geld"
    zmlab2.language["Difficulty_Easy"] = "Leicht"
    zmlab2.language["Difficulty_Medium"] = "Mittel"
    zmlab2.language["Difficulty_Hard"] = "Schwer"
    zmlab2.language["Difficulty_Expert"] = "Experte"
    zmlab2.language["Connected"] = "Verbunden!"
    zmlab2.language["Missed"] = "Verfehlt!"

    // Tent shop
    // Note: "Vamonos Pest" and "Crystale Castle" are the names of those tents so you dont need to translate them if you dont want
    zmlab2.language["tent01_title"] = "Kleines Zelt"
    zmlab2.language["tent01_desc"] = "Dieses kleine Zelt bietet Platz für 6 Maschinen."
    zmlab2.language["tent02_title"] = "Mittelgroßes Zelt"
    zmlab2.language["tent02_desc"] = "Dieses mittelgroße Zelt bietet Platz für 9 Maschinen."
    zmlab2.language["tent03_title"] = "Großes Zelt"
    zmlab2.language["tent03_desc"] = "Dieses große Zelt bietet Platz für 16 Maschinen."
    zmlab2.language["tent04_title"] = "Zirkuszelt"
    zmlab2.language["tent04_desc"] = "Dieses gestohlene Zirkuszelt bietet Platz für 24 Maschinen."

    // Machine Shop
    zmlab2.language["ventilation_title"] = "Ventilation"
    zmlab2.language["ventilation_desc"] = "Die Ventilation schützt das Zelt bei Gasaustritt."
    zmlab2.language["storage_title"] = "Lager"
    zmlab2.language["storage_desc"] = "Im Lager kannst du Chemikalien und Ausrüstung kaufen."
    zmlab2.language["furnace_title"] = "Herd"
    zmlab2.language["furnace_desc"] = "Der Herd wird zum erhitzen von Säure benötigt."
    zmlab2.language["mixer_title"] = "Mischer"
    zmlab2.language["mixer_desc"] = "Der Mischer wird zum mischen der Chemikalien verwendet."
    zmlab2.language["filter_title"] = "Filtermaschine"
    zmlab2.language["filter_desc"] = "Die Filtermaschine filtert die Flüssigkeit, um die endgültige Qualität zu verbessern."
    zmlab2.language["filler_title"] = "Füllmaschine"
    zmlab2.language["filler_desc"] = "Die Füllmaschine füllt die endgültige Mischung in Gefrierbleche."
    zmlab2.language["frezzer_title"] = "Gefrierschrank"
    zmlab2.language["frezzer_desc"] = "Der Gefrierschrank friert die Flüssigkeit ein, um das Meth danach umfüllen zu können."
    zmlab2.language["packingtable_title"] = "Packtisch"
    zmlab2.language["packingtable_desc"] = "Der Packtisch bietet eine schnelle Möglichkeit, Meth zu brechen und zu verpacken. Er kann mit einem automatischen Meth-Zerkleinerer aufgerüstet werden."

    // Item Shop
    zmlab2.language["acid_title"] = "Fluorwasserstoffsäure"
    zmlab2.language["acid_desc"] = "Fluorwasserstoffsäure ist ein Katalysator der zur Erhöhung der Reaktionsgeschwindigkeit verwendet wird."
    zmlab2.language["methylamine_title"] = "Methylamine"
    zmlab2.language["methylamine_desc"] = "Methylamin (CH3NH2) ist eine organische Verbindung und einer der Hauptbestandteile für die Herstellung von Methamphetamin."
    zmlab2.language["aluminum_title"] = "Aluminium"
    zmlab2.language["aluminum_desc"] = "Aluminium wird als chemisches Reagenz zur Reduktion von Verbindungen verwendet."
    zmlab2.language["lox_title"] = "Flüssiger Sauerstoff"
    zmlab2.language["lox_desc"] = "Der Gefrierschrank verwendet flüssigen Sauerstoff, um zu verhindern, dass die endgültige Mischung weiter reagiert."
    zmlab2.language["crate_title"] = "Transportkiste"
    zmlab2.language["crate_desc"] = "Die Transportkiste wird für den Transport von Meth verwendet."
    zmlab2.language["palette_title"] = "Palette"
    zmlab2.language["palette_desc"] = "Die Palette wird für den Transport großer Mengen Meth verwendet."
    zmlab2.language["crusher_title"] = "Meth-Zerkleinerer"
    zmlab2.language["crusher_desc"] = "Der Meth-Zerkleiner verpackt Meth automatisch, wenn er auf einem Packtisch installiert wird."

    // Meth Config
    // Note: Hard to say what about the meth should be translated and what not. Decide for yourself whats important here.
    zmlab2.language["meth_title"] = "Meth"
    zmlab2.language["meth_desc"] = "Dieses Meth ist sehr bekannt unter den Bahnhofjunkies."
    zmlab2.language["bluemeth_title"] = "Crystal Blue"
    zmlab2.language["bluemeth_desc"] = "Das ursprüngliche Meth das aufgrund der Heisenberg-Formel, sehr beliebt wurde."
    zmlab2.language["kalaxi_title"] = "Kristall"
    zmlab2.language["kalaxi_desc"] = "Die Kristalle sind vielen Drogen sehr ähnlich, da die Kristalle ein gutes Gefühl vermitteln."
    zmlab2.language["glitter_title"] = "Glitter"
    zmlab2.language["glitter_desc"] = "Glitter ist eine hochpsychedelische Droge welche kürzlich auf den Straßen von Rockford erschien."
    zmlab2.language["kronole_title"] = "Kronole"
    zmlab2.language["kronole_desc"] = "Das Medikament hat die Fähigkeit, Schmerzrezeptoren zu blockieren. Kronole ist so stark, dass es alle Gefühle blockiert, nicht nur Schmerzen."
    zmlab2.language["melange_title"] = "Melange"
    zmlab2.language["melange_desc"] = "Melange ist ein Medikament, das in der Lage ist, das Leben zu verlängern, die Vitalität zu steigern und kann bei manchen Menschen sogar das Bewusstsein stärken."
    zmlab2.language["mdma_title"] = "MDMA"
    zmlab2.language["mdma_desc"] = "MDMA wurde ab den 1970er Jahren zur Verbesserung der Psychotherapie eingesetzt und wurde in den 1980er Jahren als Straßendroge populär."

    // Update 1.0.5
    zmlab2.language["tent05_title"] = "Rundes Zelt"
    zmlab2.language["tent05_desc"] = "Dieses runde Zelt bietet Platz für 8 Maschinen."

	-- Update 1.3.2
    zmlab2.language["Won"] = "Gewonnen!"
	zmlab2.language["Lost"] = "Verloren."
    zmlab2.language["Remember"] = "Merk dir die Reihenfolge!"
	zmlab2.language["Repeat"] = "Wie war die Reihenfolge?"
end
