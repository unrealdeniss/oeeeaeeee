--[[
Server Name: AetherNetwork.gg *HIRING* Craft|Bitcoin|Gangs|Meth|Weed|FastDL
Server IP:   193.243.190.5:27034
File Path:   addons/zeros_methlab02_v1.4.8/lua/zmlab2_languages/sh_language_cz.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

/*
    Addon id: a36a6eee-6041-4541-9849-360baff995a2
    Version: v1.4.8 (stable)
*/

zmlab2 = zmlab2 or {}
zmlab2.language = zmlab2.language or {}

if (zmlab2.config.SelectedLanguage == "cz") then
    zmlab2.language["YouDontOwnThis"] = "Ty tohle nevlastníš!"
    zmlab2.language["Minutes"] = "Minut"
    zmlab2.language["Seconds"] = "Sekund"
    zmlab2.language["CratePickupFail"] = "Bedna je prázdná!"
    zmlab2.language["CratePickupSuccess"] = "Sebráno $MethAmount $MethName, Kvalita: $MethQuality%"
    zmlab2.language["Interaction_Fail_Job"] = "Nejseš správná práce proto aby jsi s tímhle použil!"
    zmlab2.language["Interaction_Fail_Dropoff"] = "Tento výhoz byl k tobě přiřazen!"
    zmlab2.language["Dropoff_assinged"] = "Výhoz přiřazen!"
    zmlab2.language["Dropoff_cooldown"] = "Výhoz cooldown!"
    zmlab2.language["Equipment"] = "Vybavení"
    zmlab2.language["Equipment_Build"] = "Stavět"
    zmlab2.language["Equipment_Move"] = "Pohybovat"
    zmlab2.language["Equipment_Repair"] = "Spravit"
    zmlab2.language["Equipment_Remove"] = "Smazat"
    zmlab2.language["NotEnoughMoney"] = "Nemáš dostatek peněz!"
    zmlab2.language["ExtinguisherFail"] = "Tento objekt nehoří!"
    zmlab2.language["Start"] = "Start"
    zmlab2.language["Drop"] = "Vyhodit"
    zmlab2.language["Move Liquid"] = "Přemístit tekutinu"
    zmlab2.language["Frezzer_NeedTray"] = "Žádnej tác s Meth nebyl nalezen!"
    zmlab2.language["ERROR"] = "ERROR"
    zmlab2.language["SPACE"] = "Zmáčkni SPACE"
    zmlab2.language["NPC_InteractionFail01"] = "Vodpal hajzle.! [Špatná práce]"
    zmlab2.language["NPC_InteractionFail02"] = "Nemáš žádnou Meth!"
    zmlab2.language["NPC_InteractionFail03"] = "Všechny výhozy mám plné, přijd' za chvilku."
    zmlab2.language["PoliceWanted"] = "Prodáno Meth!"
    zmlab2.language["MissingCrate"] = "Chybějící bedna"
    zmlab2.language["Storage"] = "SKLAD"
    zmlab2.language["ItemLimit"] = "Už si nemůžeš koupit více $ItemName!"
    zmlab2.language["TentFoldInfo01"] = "Jseš si jistej že chceš vymazat stan?"
    zmlab2.language["TentFoldInfo02"] = "Všechno vybavení vevnitř bude vymazáno také!"
    zmlab2.language["TentFoldAction"] = "SLOŽIT"
    zmlab2.language["TentType_None"] = "ŽÁDNÝ"
    zmlab2.language["TentAction_Build"] = "STAVĚT"
    zmlab2.language["TentBuild_Info"] = "Prosím vyklid'oblast!"
    zmlab2.language["TentBuild_Abort"] = "Něco je v cestě!"
    zmlab2.language["Enabled"] = "Zapnuto"
    zmlab2.language["Disabled"] = "Vypnuto"
    zmlab2.language["MethTypeRestricted"] = "Nemůžeš vyrábět tento druh Meth!"
    zmlab2.language["SelectMethType"] = "Vyber druh Methu"
    zmlab2.language["SelectTentType"] = "Vyber druh stanu"
    zmlab2.language["LightColor"] = "Světlá barva"
    zmlab2.language["Cancel"] = "Zrušit"
    zmlab2.language["Deconstruct"] = "Dekrostrukce"
    zmlab2.language["Construct"] = "Konstrukce"
    zmlab2.language["Choosepostion"] = "Vyber novou pozici"
    zmlab2.language["ChooseMachine"] = "Vyber stroj"
    zmlab2.language["Extinguish"] = "Uhas"
    zmlab2.language["PumpTo"] = "Vypumpovat do"
    zmlab2.language["ConstructionCompleted"] = "Konstrukce Dokončena!"
    zmlab2.language["Duration"] = "Délka"
    zmlab2.language["Amount"] = "Výtěžek"
    zmlab2.language["Difficulty"] = "Obtížnost"
    zmlab2.language["Money"] = "Peníze"
    zmlab2.language["Difficulty_Easy"] = "Jednoduchý"
    zmlab2.language["Difficulty_Medium"] = "Medium"
    zmlab2.language["Difficulty_Hard"] = "Těžký"
    zmlab2.language["Difficulty_Expert"] = "Expert"
    zmlab2.language["Connected"] = "Připojeno!"
    zmlab2.language["Missed"] = "Minuto!"
    -- Tent Config
    -- Note: "Vamonos Pest" and "Crystale Castle" are the names of those tents so you dont need to translate them if you dont want
    zmlab2.language["tent01_title"] = "Vamonos Pest Tent - Small"
    zmlab2.language["tent01_desc"] = "Tento stan má místo pro 6 strojů."
    zmlab2.language["tent02_title"] = "Vamonos Pest Tent - Medium"
    zmlab2.language["tent02_desc"] = "Tento stan má místo pro 9 strojů."
    zmlab2.language["tent03_title"] = "Vamonos Pest Tent - Large"
    zmlab2.language["tent03_desc"] = "Tento stan má místo pro 16 strojů."
    zmlab2.language["tent04_title"] = "Crystale Castle"
    zmlab2.language["tent04_desc"] = "Tento stan má místo pro 24 strojů."
    -- Equipment Config
    zmlab2.language["ventilation_title"] = "Ventilace"
    zmlab2.language["ventilation_desc"] = "Vyčistí oblast před Poluci."
    zmlab2.language["storage_title"] = "Sklad"
    zmlab2.language["storage_desc"] = "Z tohodle dostáváš vybavení a chemikálie."
    zmlab2.language["furnace_title"] = "Thorium furnace"
    zmlab2.language["furnace_desc"] = "Pro topení kyseliny."
    zmlab2.language["mixer_title"] = "Mixer"
    zmlab2.language["mixer_desc"] = "Kombinuje."
    zmlab2.language["filter_title"] = "Filter"
    zmlab2.language["filter_desc"] = "Použiváno k refinování quality methu."
    zmlab2.language["filler_title"] = "Filler"
    zmlab2.language["filler_desc"] = "Používáno k naplnění tácu."
    zmlab2.language["frezzer_title"] = "Frezzer"
    zmlab2.language["frezzer_desc"] = "Používáno k zastavení k poslednímu složení Methamphetaminu."
    zmlab2.language["packingtable_title"] = "Packing Table"
    zmlab2.language["packingtable_desc"] = "Využito k ničení a zabalování Methu, může být vylepšeno Ice Breakerem."
    -- Storage Config
    zmlab2.language["acid_title"] = "Hydrofluoric Acid"
    zmlab2.language["acid_desc"] = "Zrychluje reakci."
    zmlab2.language["methylamine_title"] = "Methylamine"
    zmlab2.language["methylamine_desc"] = "Methylamine (CH3NH2) je organická sloučenina a jedna z hlavních složek pro výrobu metamfetaminu."
    zmlab2.language["aluminum_title"] = "Hliníková amalgám"
    zmlab2.language["aluminum_desc"] = "Hliníkový amalgám se používá jako chemické činidlo pro redukci sloučenin."
    zmlab2.language["lox_title"] = "Liquid Oxygen"
    zmlab2.language["lox_desc"] = "Hliníkový amalgám používá jako chemický prostředek pro redukci sloučenin."
    zmlab2.language["crate_title"] = "Transportcrate"
    zmlab2.language["crate_desc"] = "Použito pro transportování Methu."
    zmlab2.language["palette_title"] = "Paleta"
    zmlab2.language["palette_desc"] = "Použito pro transportování velké množství methu."
    zmlab2.language["crusher_title"] = "Ice Breaker"
    zmlab2.language["crusher_desc"] = "Automaticky ničí a balí Meth když položen na Balící stůl."
    -- Meth Config
    -- Note: Hard to say what about the meth should be translated and what not. Decide for yourself whats important here.
    zmlab2.language["meth_title"] = "Meth"
    zmlab2.language["meth_desc"] = "Fet'áci tohle mají v oblibě."
    zmlab2.language["bluemeth_title"] = "Crystal Blue"
    zmlab2.language["bluemeth_desc"] = "Modrá jako fialka, že jo Jesse?"
    zmlab2.language["kalaxi_title"] = "Kalaxian Crystal"
    zmlab2.language["kalaxi_desc"] = "Je stejná jako hodně drog, senzace a zhulení na jednom křist'álu."
    zmlab2.language["glitter_title"] = "Glitter"
    zmlab2.language["glitter_desc"] = "Glitter je vysoce psychedelická droga a nedávný příjezd do ulic Night City. Je to opravdu silná věc, dokonce i pro přeplněné obyvatele Night City."
    zmlab2.language["kronole_title"] = "Kronole"
    zmlab2.language["kronole_desc"] = "Kronole je pouliční droga prodávaná na palubě Snowpiercer na černém trhu. Droga má schopnost blokovat receptory bolesti, Kronole je tak silný, že blokuje všechny pocity, nejen bolest."
    zmlab2.language["melange_title"] = "Melange"
    zmlab2.language["melange_desc"] = "Melange (Spice) je lék schopný prodloužit život, poskytnout zvýšenou vitalitu a vědomí a odemknout předvídavost u některých lidí."
    zmlab2.language["mdma_title"] = "MDMA"
    zmlab2.language["mdma_desc"] = "MDMA byl poprvé vyvinut v roce 1912 společností Merck. To bylo používáno k posílení psychoterapie od 70. let a v 80. letech se stalo populární jako pouliční droga."
    -- Update 1.0.5
    zmlab2.language["tent05_title"] = "Round Tent"
    zmlab2.language["tent05_desc"] = "This round tent provides room for 8 machines."

	-- Update 1.3.2
    zmlab2.language["Won"] = "Won"
	zmlab2.language["Lost"] = "Lost"
    zmlab2.language["Remember"] = "Remember!"
	zmlab2.language["Repeat"] = "Repeat!"
end
