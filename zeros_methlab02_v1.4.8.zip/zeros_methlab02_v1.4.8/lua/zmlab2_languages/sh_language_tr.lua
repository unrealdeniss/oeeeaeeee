--[[
Server Name: AetherNetwork.gg *HIRING* Craft|Bitcoin|Gangs|Meth|Weed|FastDL
Server IP:   193.243.190.5:27034
File Path:   addons/zeros_methlab02_v1.4.8/lua/zmlab2_languages/sh_language_tr.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

/*
    Addon id: a36a6eee-6041-4541-9849-360baff995a2
    Version: v1.4.8 (stable)
*/

zmlab2 = zmlab2 or {}
zmlab2.language = zmlab2.language or {}

if (zmlab2.config.SelectedLanguage == "tr") then
    zmlab2.language["YouDontOwnThis"] = "Buna sahip değilsin!"
    zmlab2.language["Minutes"] = "Dakika"
    zmlab2.language["Seconds"] = "Saniye"
    zmlab2.language["CratePickupFail"] = "Kutu boş!"
    zmlab2.language["CratePickupSuccess"] = "$MethAmount $MethName toplandı, Kalite: $MethQuality%"
    zmlab2.language["Interaction_Fail_Job"] = "Bununla etkileşime girmek için doğru meslekte değilsin!"
    zmlab2.language["Interaction_Fail_Dropoff"] = "Bu dağıtım noktası size ayarlanmamış!"
    zmlab2.language["Dropoff_assinged"] = "Dağıtım noktası ayarlandı!"
    zmlab2.language["Dropoff_cooldown"] = "Dağıtım noktası bekleme süresi!"
    zmlab2.language["Equipment"] = "Ekipman"
    zmlab2.language["Equipment_Build"] = "İnşa Et"
    zmlab2.language["Equipment_Move"] = "Hareket Ettir"
    zmlab2.language["Equipment_Repair"] = "Tamir Et"
    zmlab2.language["Equipment_Remove"] = "Kaldır"
    zmlab2.language["NotEnoughMoney"] = "Yeterli paraya sahip değilsin!"
    zmlab2.language["ExtinguisherFail"] = "Obje yanmıyor!"
    zmlab2.language["Start"] = "Başlat"
    zmlab2.language["Drop"] = "Bırak"
    zmlab2.language["Move Liquid"] = "Sıvıyı Hareket Ettir"
    zmlab2.language["Frezzer_NeedTray"] = "Sıvı meth içeren bir tepsi bulunamadı!"
    zmlab2.language["ERROR"] = "HATA"
    zmlab2.language["SPACE"] = "BOŞLUK tuşuna tıklayın"
    zmlab2.language["NPC_InteractionFail01"] = "Senin gibi garibanlarla konuşmuyorum! [Geçersiz Meslek]"
    zmlab2.language["NPC_InteractionFail02"] = "Üstünde hiç meth yok!"
    zmlab2.language["NPC_InteractionFail03"] = "Sana verebileceğim dağıtım noktası bulunmamakta, sonra tekrar gel."
    zmlab2.language["PoliceWanted"] = "Meth Satıldı!"
    zmlab2.language["MissingCrate"] = "Eksik Kutu"
    zmlab2.language["Storage"] = "DEPO"
    zmlab2.language["ItemLimit"] = "$ItemName için varlık limitine ulaştın!"
    zmlab2.language["TentFoldInfo01"] = "Çadırı kaldırmak istediğine emin misin?"
    zmlab2.language["TentFoldInfo02"] = "İçeride bulunan tüm ekipmanlar da kaldırılacak!"
    zmlab2.language["TentFoldAction"] = "KATLA"
    zmlab2.language["TentType_None"] = "HİÇ"
    zmlab2.language["TentAction_Build"] = "INŞA ET"
    zmlab2.language["TentBuild_Info"] = "Lütfen bölgeyi temizleyin!"
    zmlab2.language["TentBuild_Abort"] = "Yolda birşey vardı!"
    zmlab2.language["Enabled"] = "Aktif"
    zmlab2.language["Disabled"] = "Deaktif"
    zmlab2.language["MethTypeRestricted"] = "Bu meth türünü üretemezsin!"
    zmlab2.language["SelectMethType"] = "Meth Türünü Seçiniz"
    zmlab2.language["SelectTentType"] = "Çadır Türünü Seçiniz"
    zmlab2.language["LightColor"] = "Işık Rengini Seçiniz"
    zmlab2.language["Cancel"] = "İptal"
    zmlab2.language["Deconstruct"] = "Yık"
    zmlab2.language["Construct"] = "İnşa Et"
    zmlab2.language["Choosepostion"] = "Yeni Pozisyon Seçin"
    zmlab2.language["ChooseMachine"] = "Makine Seçin"
    zmlab2.language["Extinguish"] = "Söndür"
    zmlab2.language["PumpTo"] = "Şuna pompala"
    zmlab2.language["ConstructionCompleted"] = "İnşaat tamamlandı!"
    zmlab2.language["Duration"] = "Süre"
    zmlab2.language["Amount"] = "Miktar"
    zmlab2.language["Difficulty"] = "Zorluk"
    zmlab2.language["Money"] = "Para"
    zmlab2.language["Difficulty_Easy"] = "Kolay"
    zmlab2.language["Difficulty_Medium"] = "Orta"
    zmlab2.language["Difficulty_Hard"] = "Zor"
    zmlab2.language["Difficulty_Expert"] = "Uzman"
    zmlab2.language["Connected"] = "Bağlandı!"
    zmlab2.language["Missed"] = "Iskalandı!"

    // Tent Config
    // Note: "Vamonos Pest" and "Crystale Castle" are the names of those tents so you dont need to translate them if you dont want
    zmlab2.language["tent01_title"] = "Vamonos Pest Çadırı - Küçük"
    zmlab2.language["tent01_desc"] = "6 makine sığabilen küçük bir çadır."
    zmlab2.language["tent02_title"] = "Vamonos Pest Çadırı - Orta"
    zmlab2.language["tent02_desc"] = "9 makine sığabilen orta boy bir çadır."
    zmlab2.language["tent03_title"] = "Vamonos Pest Çadırı - Büyük"
    zmlab2.language["tent03_desc"] = "16 makine sığabilen büyük boy bir çadır."
    zmlab2.language["tent04_title"] = "Crystale Castle"
    zmlab2.language["tent04_desc"] = "24 makine sığdırabileceğin çalıntı bir sirk çadırı."

    // Equipment Config
    zmlab2.language["ventilation_title"] = "Havalandırma"
    zmlab2.language["ventilation_desc"] = "Çevrenin kirlenmesini engeller."
    zmlab2.language["storage_title"] = "Depo"
    zmlab2.language["storage_desc"] = "Kimyasal ve ekipmanları sağlar."
    zmlab2.language["furnace_title"] = "Toryum fırını"
    zmlab2.language["furnace_desc"] = "Asiti ısıtmayı sağlar."
    zmlab2.language["mixer_title"] = "Karıştırıcı"
    zmlab2.language["mixer_desc"] = "Bileşenleri karıştırmayı sağlar."
    zmlab2.language["filter_title"] = "Filtre"
    zmlab2.language["filter_desc"] = "Çıkan karışımı filtrelemeyi sağlar ve ürünün kalitesini arttırır."
    zmlab2.language["filler_title"] = "Doldurucu"
    zmlab2.language["filler_desc"] = "Dondurucu tepsilerini doldurmayı sağlar."
    zmlab2.language["frezzer_title"] = "Dondurucu"
    zmlab2.language["frezzer_desc"] = "Çıkan metanfetamini son reaksiyonunu yaşatır ve hazır hale getirir."
    zmlab2.language["packingtable_title"] = "Paketleme Masası"
    zmlab2.language["packingtable_desc"] = "Meth hazırlamayı hızlandırır. 12 tepsi sığdırabilirsin. Otomatik buz kırıcı ile güçlendirebilirsin."

    // Storage Config
    zmlab2.language["acid_title"] = "Hidroflorik Asit"
    zmlab2.language["acid_desc"] = "Reaksiyonun kaliteseini arttırabileceğin bir asit."
    zmlab2.language["methylamine_title"] = "Metilamin"
    zmlab2.language["methylamine_desc"] = "Metilamin (CH3NH2) metanfetaminin ana maddelerinden biri olan organik bir bileşendir."
    zmlab2.language["aluminum_title"] = "Aliminyum"
    zmlab2.language["aluminum_desc"] = "Aliminyum amalgam, bileşikleri azaltmak için kullanılan kimyasal reaktiftir."
    zmlab2.language["lox_title"] = "Sıvı Oksijen"
    zmlab2.language["lox_desc"] = "Sıvı oksijen metanfetaminin son adımını yani dondurmayı sağlamak için kullanılan bir bileşendir."
    zmlab2.language["crate_title"] = "Taşıma Kutusu"
    zmlab2.language["crate_desc"] = "Yüklü miktarda meth taşımak için kullanılır."
    zmlab2.language["palette_title"] = "Palet"
    zmlab2.language["palette_desc"] = "Yüklü miktarda meth taşımak için kullanılır."
    zmlab2.language["crusher_title"] = "Buz Kırıcı"
    zmlab2.language["crusher_desc"] = "Masaya gelen methi otomatik olarak kırıp paketlemeye yarar."

    // Meth Config
    // Note: Hard to say what about the meth should be translated and what not. Decide for yourself whats important here.
    zmlab2.language["meth_title"] = "Meth"
    zmlab2.language["meth_desc"] = "Sokak torbacılarının sattığı düz meth."
    zmlab2.language["bluemeth_title"] = "Kristal Mavisi"
    zmlab2.language["bluemeth_desc"] = "Heisenberg'in orijinal formülü."
    zmlab2.language["kalaxi_title"] = "Kalaksian Kristali"
    zmlab2.language["kalaxi_desc"] = "Kristaller sana aynı zevki verdiğinden dolayı Kalaksian Kristali diğer uyuşturuculara çok benzer."
    zmlab2.language["glitter_title"] = "Simli Cin"
    zmlab2.language["glitter_desc"] = "Simli Cin Night Street sokaklarında bolca bulunan saykodelik bir haptır. Gerçekten sağlam bir haptır, Night Street sivilleri bile buna dayanamıyor."
    zmlab2.language["kronole_title"] = "Kronol"
    zmlab2.language["kronole_desc"] = "Kronol Kar Küreyici içerisinde satılan bir uyuşturucu çeşididir. Kronol, vücudundaki acı reseptörlerini bile engelleyebilir, sadece acıyı da değil tüm hislerinizi engelleyebilir."
    zmlab2.language["melange_title"] = "Melanj"
    zmlab2.language["melange_desc"] = "Melanj (Baharat) ömrünüzü uzatabilen bir uyuşturucudur, size yüksek farkındalık ve yüksek enerji bahşedebilir hatta bazı insanların geleceği görmesini bile sağlayabilir."
    zmlab2.language["mdma_title"] = "Ekstazi"
    zmlab2.language["mdma_desc"] = "Ekstazi 1912 yılında Merck tarafından üretildi. Psikoterapileri geliştirmek için 1970 yıllarında kullanıldı ve 1980 yıllarında popüler bir sokak uyuşturucusu oldu."

    // Update 1.0.5
    zmlab2.language["tent05_title"] = "Round Tent"
    zmlab2.language["tent05_desc"] = "This round tent provides room for 8 machines."

	-- Update 1.3.2
    zmlab2.language["Won"] = "Won"
	zmlab2.language["Lost"] = "Lost"
    zmlab2.language["Remember"] = "Remember!"
	zmlab2.language["Repeat"] = "Repeat!"
end
